function [DATA, partition_nrecords] = partition_original_data(input_dir, domain_discrete, Data, num_discrete_attr, nattr, numofpartitions)
DATA = zeros(size(Data,1), (size(Data,2)-num_discrete_attr)); 
partition_nrecords = zeros(1, numofpartitions);
begin_index = 1;   index = 1;
if num_discrete_attr == 3
for i1 = 1: domain_discrete(1,1)
    for i2 = 1: domain_discrete(1,2)
        for i3 = 1: domain_discrete(1,3)
            mkdir([ input_dir '/' num2str(index)]);
            DATA1 = Data( find(Data(:,1)==i1 & Data(:,2)==i2 & Data(:,3)==i3),:);
            csvwrite([ input_dir '/' num2str(index) '/' num2str(index) '.csv'], DATA1);
            for i = (num_discrete_attr+1): nattr        
                csvwrite([ input_dir '/' num2str(index) '/' num2str(index) num2str(i) '.csv'], DATA1(:,i));
            end
          %  DATA = [DATA' DATA1']';
            partition_nrecords(1, index) = size(DATA1, 1);
        %    DATA(begin_index:(begin_index+partition_nrecords(1, index)-1), :) = DATA1;
        %    begin_index = begin_index+partition_nrecords(1, index);
            index = index + 1;
        end
    end
end
end
if num_discrete_attr == 1
    for i1 = 1: domain_discrete(1,1)
         mkdir( [input_dir '/' num2str(index)]);
            DATA1 = Data( find(Data(:,1)==i1),:);
            csvwrite([input_dir, '/', num2str(index), '/', num2str(index), '.csv'], DATA1);
            for i = (num_discrete_attr+1): nattr        
                csvwrite([ input_dir, '/',num2str(index), '/', num2str(index), num2str(i), '.csv'], DATA1(:,i));
            end
        %    DATA = [DATA' DATA1']';
           partition_nrecords(1, index) = size(DATA1, 1);
       %     DATA(begin_index:(begin_index+partition_nrecords(1, index)-1), :) = DATA1;
       %     begin_index = begin_index+partition_nrecords(1, index);
            index = index + 1;
     end
end
end

