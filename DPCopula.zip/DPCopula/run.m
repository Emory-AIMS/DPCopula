input_dir = '/var/www/django/dp/dp/media/3_34';
epsilon = 1.0; filename = 'ACS4D_2.csv';  num_discrete_attr = 1; attribute_domain = [2 992 999 95];
Gaussian_copula_hybrid(num_discrete_attr, epsilon, input_dir, filename, attribute_domain);
path_original = 'D:/My_file2/DP-Gaussian-Copula/DPCopula/ACS4D.csv';
path_sample = 'D:\My_file2\DP-Gaussian-Copula\DPCopula\sample-acs1.csv';
query_times = 100;
sanity_bound = 500;
[rel_av, abs_av] = query(path_original, path_sample, query_times, sanity_bound, attribute_domain, num_discrete_attr)