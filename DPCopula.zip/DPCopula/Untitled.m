D = csvread('D:\My_file2\DP-Gaussian-Copula\finished_Data\Wavelet-ACS4D\ACS4D.csv');
D_sample = csvread('D:\My_file2\DP-Gaussian-Copula\DPCopula\sample-acs1.csv');
Data = D(:,1);
Data_sample = D_sample(:,4);
[n,x] = hist(Data,max(Data)); %   n: the number of elements in each bin
                              %   x: location of each bin center on the x-axis
[n2,x2] = hist(Data_sample, max(Data_sample));
h1=bar(x,n,'hist')
hold on; 
h2=bar(x2,n2,'hist'); 
hold off
set(h1,'facecolor','g','EdgeColor','g')
set(h2,'facecolor','none','edgecolor','r')
hleg1 = legend('original-histogram','noisy-histogram','FontWeight','bold','FontSize',25);
title(['\fontsize{16}The histogram of ' '\fontsize{16}age']);

input_dir = '/home/hli57';
filename = 'ACS4D.csv';
epsilon = 1.0;