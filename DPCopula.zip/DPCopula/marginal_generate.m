function marginal_generate(nattr, epsilon1, times, dir, epsilon)
% generate KD marginal histogram to file 1 ... file 5
   
    for t = 1: times
        fprintf('%d\n', t);
        for filename = 1:nattr
            command1 = ['java  -jar diff.jar', ' ', dir, num2str(filename),'.csv '];
            command2 = [command1, ' ', dir, num2str(epsilon), '\', num2str(t), '\', num2str(filename+10), '.csv'];
            command = [command2, ' ', num2str(epsilon1/10), ' ', num2str(epsilon1 - epsilon1/10)];
            system(command);
            filepath = [dir, num2str(epsilon), '\', num2str(t), '\', num2str(filename+10), '.csv'];          
            fid=fopen(filepath);
            a{1}=fgets(fid);   b1 = a{1};
            b1 = b1(1, 14*(2*2)+2*2+25+9: size(b1, 2));
            m = ' ';      xlswrite(filepath, m, 'A1:O1');
            m_nattr = 1;
            loc = zeros(1, m_nattr*2+1);  k_loc = 1;

            for i = 1: 200   % 100 is a max_virtual bound for b1, actual length should be much smaller
                if  b1(1, i) == ','
                    loc(1, k_loc) = i;     k_loc = k_loc + 1;
                end
                if  k_loc > m_nattr*2+1
                    break;
                end
            end
            integers = zeros(1, m_nattr*2+2);  
            integers(1) = str2num( b1(1:(loc(1)-1)) );
            for i = 2: m_nattr*2+1 
                integers(i) = str2num( b1((loc(i-1)+1):(loc(i)-1)) );
            end
            integers(m_nattr*2+2) = str2num( b1( (loc(m_nattr*2+1)+1): size(b1, 2)  )  );
            xlswrite(filepath,integers);
            fclose(fid);
        end
    end
end

