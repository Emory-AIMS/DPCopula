#/bin/sh
python setup.py build_ext -b ./lib/

