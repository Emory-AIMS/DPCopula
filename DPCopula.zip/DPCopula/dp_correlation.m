function nRHO = dp_correlation( nattr, nrecords, epsilon2, RHO)
% RHO: original Kendall's tau correlation matrix
% 1. Compute DP correlation matrix and keep it in nRHO
% 2. Transform it to semi-positive definite matrix

%  Compute noisy Kendall's tau correlation matrix    Output nRHO     %
nRHO = zeros(nattr, nattr);
for i = 1: nattr                                         % Set true Kendall's tau matrix
    for j = (i+1): nattr
        noise=exprnd((4/(nrecords + 1))/epsilon2,1,1)-exprnd((4/(nrecords + 1))/epsilon2,1,1);
        nRHO(i, j) = RHO(i, j) + noise;
        if nRHO(i, j) > 1
               nRHO(i, j) = 1;
        elseif nRHO(i, j) <-1
               nRHO(i, j) = -1;
        end
        nRHO(j, i) = nRHO(i, j);
    end
    nRHO(i, i) = 1;
end
nRHO = sin(1.5708*nRHO);
sym_positive = 0;
while 1
    [V, D] = eig(nRHO);    
    for i = 1: nattr
        if    D(i, i) < 0
            sym_positive = 1;    disp('Non-semi positive matrix exists! ');
            D(D<0) = -D(D<0);                    % change non-positive definite matrix to semi-positive matrix
            nRHO = V*D*V';
            d = diag(nRHO);
            h = 1./d;
            nRHO = nRHO*diag(h); 
            for m = 1:nattr
                for n = (m+1):nattr
                    if m~= n
                        nRHO(n,m) = nRHO(m,n);
                    end
                end
            end
            break;
        end
    end
    if sym_positive == 0
        break;
    end
    sym_positive = 0;
end
disp('nRHO is : ');
fprintf('%d\n', nRHO);
for i = 1: nattr
    nRHO(i, i) = 1;
end
end

