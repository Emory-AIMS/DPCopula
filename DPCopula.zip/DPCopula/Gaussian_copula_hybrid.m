function Gaussian_copula_hybrid(epsilon, input_dir, filename, metaname)
margin_method = 'EFPA';
[Data, nrecords, nattr, num_discrete_attr, attribute, attribute_domain] = readMeta(input_dir, filename, metaname);

num_sampling = 35000;
num_numerical_attr = nattr - num_discrete_attr;
eps_partition = 0.01;
epsilon = epsilon - eps_partition;
ratio_x = 8;                               % Set ratio_x
epsilon2 = epsilon/(num_numerical_attr*ratio_x + 0.5*num_numerical_attr*(num_numerical_attr-1));  %privacy budget for each coefficient
epsilon1 = ratio_x*epsilon2;    % privacy budget for each margin

domain_discrete = attribute_domain(1, 1:num_discrete_attr);  % e.g. domain_discrete = [2 2 2]; 
lower_bound = ones(1, num_numerical_attr);
upper_bound = attribute_domain(1, (num_discrete_attr+1):nattr);
numofpartitions = prod(domain_discrete);
dp_nrecords = zeros(1, numofpartitions);

%=========== Partition original data ==================  %
[DATA, partition_nrecords] = partition_original_data(input_dir, domain_discrete, Data, num_discrete_attr, nattr, numofpartitions);

%=========== Compute dp_nrecords for each partition ==================  %
for partition_i = 1: numofpartitions
    dp_nrecords(1, partition_i) = partition_nrecords(1, partition_i) + exprnd(1/eps_partition , 1, 1) - exprnd(1/eps_partition , 1, 1);
end
r = nrecords/sum(dp_nrecords);
dp_nrecords = round(dp_nrecords * r);
dp_nrecords(1,numofpartitions) = dp_nrecords(1,numofpartitions) + (nrecords-sum(dp_nrecords));

syntheticData = [];
for partition_i = 1: numofpartitions
     % ========= read Original dataset in the current partition =========
    DATA = csvread([input_dir, '/',num2str(partition_i), '/', num2str(partition_i), '.csv']);
    a = DATA(1, 1:num_discrete_attr);
    DATA = DATA(:, (num_discrete_attr+1):nattr);
        
    %  compute DP marginal histograms
    if margin_method == 'EFPA'
        path = [input_dir, '/',num2str(partition_i) '/h'];
        invCDF = margin_EFPA(path, input_dir, DATA, partition_i, num_discrete_attr, nattr, dp_nrecords, upper_bound, lower_bound, epsilon1);
    elseif margin_method == 'DPCube'
        path = [input_dir, '/',num2str(partition_i) '/h'];
        invCDF = margin_DPCube(path, input_dir, DATA, partition_i, num_discrete_attr, nattr, dp_nrecords, upper_bound, lower_bound, epsilon1);
    end  
    
     % ========= compute DP correlation matrix =========
    if dp_nrecords(partition_i) > num_sampling
        sampling_rate = num_sampling/dp_nrecords(partition_i);
    else
        sampling_rate = 1;
    end
    tic;
    RHO = kendall_tau(DATA, num_numerical_attr, sampling_rate);
    disp('The time used to comput nRHO is');
    toc;
    nRHO = dp_correlation(num_numerical_attr, dp_nrecords(partition_i)*sampling_rate, epsilon2, RHO);

    % Generate psedu Gaussian copula data in U
    U = copularnd('gaussian', nRHO, dp_nrecords(partition_i));
        
    % Sample DP synthetic data
    sample = zeros(dp_nrecords(partition_i), nattr);
    sample(:, 1:num_discrete_attr) = repmat(a, dp_nrecords(partition_i), 1);
    for i = (num_discrete_attr+1): nattr
        sample(:, i) =  invCDF( ceil( dp_nrecords(partition_i)*U(:,i-num_discrete_attr)), (i-num_discrete_attr) )+1;
    end
    % Merge DP synthetic data of all partition
    syntheticData = [syntheticData' round(sample')]';
end
csvwrite([input_dir, '/output_',filename], syntheticData);
    % Draw marginal histogram
for i = (num_discrete_attr+1): nattr
    draw_histogram(Data, syntheticData, i,attribute_domain, input_dir, attribute);
end
end








