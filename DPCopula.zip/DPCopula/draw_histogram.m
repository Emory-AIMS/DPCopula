function draw_histogram(Data, syntheticData, i, attribute_domain, input_dir, attribute)
G1=figure('Visible','Off');  
[n,x] = hist(Data(:,i), attribute_domain(1,i)); 
[n2,x2] = hist(syntheticData(:,i), attribute_domain(1,i));
h1=bar(x,n,'hist');
hold on; 
h2=bar(x2,n2,'hist'); 
hold off;
set(h1,'facecolor','g','EdgeColor','g');
set(h2,'facecolor','none','edgecolor','r');
hleg1 = legend('original-histogram','noisy-histogram');
title(attribute(i));
print(G1,strcat(input_dir, '/','h',num2str(i),'.png'),'-dpng')
end

