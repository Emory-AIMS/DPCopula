function RHO = kendall_tau(DATA, nattr, sampling_rate)
% Select DATA with sampling_rate to reduce computation time
%nrecords = size(DATA, 1)/sampling_rate;
DATA = DATA(1:(size(DATA,1)*sampling_rate), :);
RHO = zeros(nattr, nattr);
for i = 1: nattr                                       
    for j = (i+1): nattr
        RHO(i, j) = corr(DATA(:, i), DATA(:, j), 'type', 'Kendall');
        RHO(j, i) = RHO(i, j);
    end
    RHO(i, i) = 1;
end

end

