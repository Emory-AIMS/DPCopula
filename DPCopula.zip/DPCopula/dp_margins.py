'''
@author: Gergely Acs <acs@crysys.hu>
'''

from lib.SPA import *
from lib.LPA import *
from lib.Histogram import *
from lib.EFPA import *
from lib.Utils import *

#import scipy.stats
import time
import math
import os
import sys

sensitivity = 1.0
    
def run(dataset, input_dir1, output_dir1, budget):  
    histogram_name = dataset + ".txt"
    output_dir = output_dir1+"/"
    input_dir = input_dir1+"/"
    
    b = sensitivity / budget

    # Reading input histogram
    input = Histogram()
    input.loadFromFile(input_dir + histogram_name)

    # EFPA
    output = Histogram(EFPA(input.bins, math.sqrt(sensitivity), budget))
    output.dump(output_dir + dataset + "-"+str(budget)+".txt")
    return output

# Entry point
if __name__ == "__main__":
   dataset = str(sys.argv[1])
   input_dir1 = str(sys.argv[2])
   output_dir1 = str(sys.argv[3])
   budget = float(sys.argv[4])
   run(dataset, input_dir1, output_dir1, budget)




              


