function [ Data, nrecords, nattr, num_discrete_attr, attribute, attribute_domain, lower_bound, upper_bound ] = readMeta(input_dir, filename, metaname)
Data = csvread([ input_dir '/' filename ]); 
nrecords = size(Data,1);

fid = fopen([input_dir '/' metaname]);
attribute = [];
discrete_domain = []; numerical_domain = [];
discrete_lower = [];  numerical_lower = [];
discrete_upper = [];  numerical_upper = [];
discrete_location = [];
num_discrete_attr = 0;
tline = fgets(fid);
nattr = 0;
while ischar(tline)
    C= strsplit(strtrim(tline), '[\s,\[\]]+','DelimiterType','RegularExpression');
    if strcmp(C(1,1), '@attribute') && ((strcmp(C(1,3),'numeric')&&isnumeric(str2num(cell2mat(C(1,5)))))||(strcmp(C(1,3),'categorical'))) ...
       && isnumeric(str2num(cell2mat(C(1,4)))) 
	    attribute = [attribute, C(1,2)];
		nattr = nattr + 1;
	    if strcmp(C(1,3),'categorical')
			num_discrete_attr = num_discrete_attr + 1;
		    discrete_location = [discrete_location, nattr];
			discrete_domain = [discrete_domain, str2num(cell2mat(C(1,4)))]; 
			discrete_lower = [discrete_lower, 1];  discrete_upper = [discrete_upper,str2num(cell2mat(C(1,4)))];
        else
			numerical_domain = [numerical_domain, str2num(cell2mat(C(1,5))) - str2num(cell2mat(C(1,4)))+1];
			numerical_lower = [numerical_lower, str2num(cell2mat(C(1,4)))];  numerical_upper = [numerical_upper, str2num(cell2mat(C(1,5)))];
	    end
    end
    tline = fgets(fid);
end
fclose(fid);
attribute_domain = [discrete_domain numerical_domain];
lower_bound = [discrete_lower numerical_lower];
upper_bound = [discrete_upper numerical_upper];
discrete_Data = Data(:, discrete_location);
Data(:, discrete_location) = [];
Data = [discrete_Data Data];
discrete_attribute = attribute(1, discrete_location);
attribute(:, discrete_location) = [];
attribute = [discrete_attribute, attribute];
end
