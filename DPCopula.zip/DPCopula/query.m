function [rel_av, abs_av] = query(path_original, path_sample, query_times, sanity_bound, attribute_domain, num_discrete_attr)
DATA = csvread(path_original);
n = size(DATA, 1);   nattr = size(DATA, 2);     % n: # of rows;  num_a: # of columns
sample = csvread(path_sample);
answer_o = zeros(query_times,1);
answer_syn = zeros(query_times,1);
lower_bound = ones(1, nattr);
upper_bound = attribute_domain;
q_l = zeros(size(lower_bound, 2),1);
q_m = zeros(size(lower_bound, 2),1);
for j = 1:query_times
    for i = 1: num_discrete_attr
        q_l(i,1) = randint(1,1,[1 attribute_domain(1,i)]);
        q_m(i,1) = randint(1,1,[1 attribute_domain(1,i)]);
    end
    for i = (num_discrete_attr+1):nattr
        q_l(i,1) = lower_bound(i)+(upper_bound(i)-lower_bound(i)+1).*rand(1,1);
        q_m(i,1) = lower_bound(i)+(upper_bound(i)-lower_bound(i)+1).*rand(1,1);
    end
     % ===========  query answer from original data ============= %
    ind1 = find(DATA(:,1)<=max(q_l(1,1), q_m(1,1)));
    ind2 = find(DATA(:,1)>=min(q_l(1,1), q_m(1,1)));
    ind_o  = intersect(ind1,ind2);
    for i = 2: nattr
        ind1 = find(DATA(:,i)<=max(q_l(i,1), q_m(i,1)));
        ind2 = find(DATA(:,i)>=min(q_l(i,1), q_m(i,1)));
        ind3 = intersect(ind1,ind2);
        ind_o = intersect(ind_o,ind3);
    end
     % ===========  query answer from synthetic data ============= %
    ind1 = find(sample(:,1)<=max(q_l(1,1), q_m(1,1)));
    ind2 = find(sample(:,1)>=min(q_l(1,1), q_m(1,1)));
    ind_s  = intersect(ind1,ind2);
    for i = 2: nattr
        ind1 = find(sample(:,i)<=max(q_l(i,1), q_m(i,1)));
        ind2 = find(sample(:,i)>=min(q_l(i,1), q_m(i,1)));
        ind3 = intersect(ind1,ind2);
        ind_s = intersect(ind_s,ind3);
    end
    answer_o(j) = size(ind_o, 1);
    answer_syn(j) = size(ind_s,1);
end
rel_err = abs(answer_o-answer_syn)./max(answer_o, sanity_bound);
abs_err = abs(answer_o-answer_syn);
rel_err = sort(rel_err);
rel_m = median(rel_err);
abs_err = sort(abs_err);
abs_m = median(abs_err);
rel_av = sum(rel_err)/query_times;
abs_av = sum(abs_err)/query_times;
C = strsplit(path_original,'/');
C = C(1, 1:(size(C,2)-1));
path=sprintf('%s/', C{:});
csvwrite([path '/utility.csv'], [rel_av abs_av]);
disp('Below is the utility output:');
fprintf('%.4f %.4f\n', rel_av, abs_av);
end

