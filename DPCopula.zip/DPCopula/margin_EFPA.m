function invCDF = margin_EFPA(path, input_dir, DATA, partition_i, num_discrete_attr, nattr, dp_nrecords, upper_bound, lower_bound, epsilon1)
num_numerical_attr = nattr - num_discrete_attr; 
    for i = 1: num_numerical_attr
        Dm = DATA(:,i);
        um= unique(Dm);     % m2 is index vector of histogram where the count is NOT zero, is position
        countm = histc(Dm, um);   % the count vector corresponding to m2, is non-zero count
        hm = zeros(upper_bound(1,i)-lower_bound(1,i)+1,1);
        hm(um,1) = countm;
        pathmw = [path,num2str(partition_i),num2str(i+num_discrete_attr),'.txt'];
        fid = fopen(pathmw,'wt');
        for k=1:(upper_bound(1,i)-lower_bound(1,i)+1)
            p = hm(k);  
            fprintf(fid,'%d\n',p);
        end
        fclose(fid);
    end
    for i = (num_discrete_attr+1): nattr  
        dataset = ['h' num2str(partition_i) num2str(i) ];
        input_dir1  = [input_dir '/' num2str(partition_i) '/'];
        output_dir1 = input_dir1;
       % python('dp_margins.py', dataset, input_dir1, output_dir1, num2str(epsilon1));
        system(['python dp_margins.py', ' ',dataset, ' ',input_dir1,' ', output_dir1,' ', num2str(epsilon1)]);
    end
    n_histcount = zeros(1, num_numerical_attr);
    for i = (num_discrete_attr+1): nattr  
        pathm = [input_dir, '/',num2str(partition_i), '/h', num2str(partition_i), num2str(i), '-', num2str(epsilon1),'.txt'];
        H = textread(pathm);
        H = H*(dp_nrecords(partition_i)/sum(H));
        n_histcount(1,i-num_discrete_attr) = round(sum(H));
    end
    invCDF = zeros(max(n_histcount),num_numerical_attr);
    for i = (num_discrete_attr+1): nattr  
        pathm = [input_dir, '/',num2str(partition_i), '/h', num2str(partition_i), num2str(i), '-', num2str(epsilon1),'.txt'];
        H = textread(pathm);
        H = H*(dp_nrecords(partition_i)/sum(H));
        index_begin = 1;
        for j = 1:size(H,1)
            span = round(H(j));
            index_end = index_begin+span-1;
            invCDF(index_begin:index_end,i-num_discrete_attr) = j;
            index_begin = index_end + 1;
        end
    end
end

