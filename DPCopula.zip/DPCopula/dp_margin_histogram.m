function [hist, n_histcount] = dp_margin_histogram( nattr, t, dir, epsilon )

     n_histcount = zeros(1, nattr);
     index_KD = zeros(1, nattr);
     filepath = [dir, num2str(epsilon), '\', num2str(t), '\'];     
        filepath_A = strcat(filepath, '\11.csv');
        A = csvread(filepath_A);                 % 1st dimension --- A
        filepath_H = strcat(filepath, '\12.csv');
        H = csvread(filepath_H);                 % 2nd dimension --- H
        [ma,na]=size(A);   [mh,nh]=size(H);   hist1=[ ];   hist2=[ ];
        if  nattr >= 3
            filepath_INC = strcat(filepath, '\13.csv');
            INC = csvread(filepath_INC);         % 3rd dimension --- INC
            [mi,ni]=size(INC);      hist3=[ ];
        end
        if  nattr >= 4
            filepath_OC = strcat(filepath, '\14.csv');
            OC = csvread(filepath_OC);           % 4th dimension --- OC
            [mo,no]=size(OC);   hist4=[ ];       
        end
        if  nattr >= 5
            filepath_WC = strcat(filepath, '\15.csv');
            WC = csvread(filepath_WC);           % 5th dimension --- WC
            [mw, nw]=size(WC);      hist5=[ ];
        end
        if  nattr >= 6
            filepath_SIX = strcat(filepath, '\16.csv');
            SIX = csvread(filepath_SIX);           % 6th dimension --- SIX
            [msix, nsix]=size(SIX);      hist6=[ ];
        end
        if  nattr >= 7
            filepath_SEV = strcat(filepath, '\17.csv');
            SEV = csvread(filepath_SEV);           % 7th dimension --- SEV
            [msev, nsev]=size(SEV);      hist7=[ ];
        end
        if  nattr >= 8
            filepath_EIG = strcat(filepath, '\18.csv');
            EIG = csvread(filepath_EIG);           % 8th dimension --- EIG
            [meig, neig]=size(EIG);      hist8=[ ];
        end
         %  set noisy marginal distribution   %
   for  i = 1:ma
     min = A(i,1);   max = A(i,2);
     hist_element1 = min + (max-min)*rand(round(A(i,4)),1);
     n_histcount(1, 1) = n_histcount(1, 1) + round(A(i,4));
     hist1=[hist1, hist_element1'];  
   end
   hist1=hist1';     clear hist_element1;
   index_KD(1, 1) = ma;

   for  i = 1:mh
     min = H(i,1);   max = H(i,2);
     hist_element2 = min + (max-min)*rand(round(H(i,4)),1);
     n_histcount(1, 2) = n_histcount(1, 2) + round(H(i,4));
     hist2=[hist2, hist_element2'];  
   end
   hist2=hist2';     clear hist_element2;
   index_KD(1, 2) = mh;
   
   if nattr >= 3
      for  i = 1:mi
        min = INC(i,1); max = INC(i,2);
        hist_element3 = min + (max-min)*rand(round(INC(i,4)),1);
        n_histcount(1, 3) = n_histcount(1, 3) + round(INC(i,4));
        hist3=[hist3, hist_element3'];  
      end
      hist3=hist3';     clear hist_element3;
      index_KD(1, 3) = mi;
   end
   if nattr >= 4
      for  i = 1:mo
        min = OC(i,1); max = OC(i,2);
        hist_element4 = min + (max-min)*rand(round(OC(i,4)),1);
        n_histcount(1, 4) = n_histcount(1, 4) + round(OC(i,4));
        hist4 = [hist4, hist_element4'];  
      end
      hist4=hist4';     clear hist_element4;
      index_KD(1, 4) = mo;
   end
   if nattr >= 5
      for  i = 1:mw
        min = WC(i,1); max = WC(i,2);
        hist_element5 = min + (max-min)*rand(round(WC(i,4)),1);
        n_histcount(1, 5) = n_histcount(1, 5) + round(WC(i,4));
        hist5 = [hist5, hist_element5'];  
      end
      hist5 = hist5';     clear hist_element5;
      index_KD(1, 5) = mw; 
   end
   if nattr >= 6
      for  i = 1:msix
        min = SIX(i,1);     max = SIX(i,2);
        hist_element6 = min + (max-min)*rand(round(SIX(i,4)),1);
        n_histcount(1, 6) = n_histcount(1, 6) + round(SIX(i,4));
        hist6 = [hist6, hist_element6'];  
      end
      hist6 = hist6';     clear hist_element6;
      index_KD(1, 6) = msix; 
   end
   if nattr >= 7
      for  i = 1:msev
        min = SEV(i,1); max = SEV(i,2);
        hist_element7 = min + (max-min)*rand(round(SEV(i,4)),1);
        n_histcount(1, 7) = n_histcount(1, 7) + round(SEV(i,4));
        hist7 = [hist7, hist_element7'];  
      end
      hist7 = hist7';     clear hist_element7;
      index_KD(1, 7) = msev; 
   end
   if nattr >= 8
      for  i = 1:meig
        min = EIG(i,1); max = EIG(i,2);
        hist_element8 = min + (max-min)*rand(round(EIG(i,4)),1);
        n_histcount(1, 8) = n_histcount(1, 8) + round(EIG(i,4));
        hist8 = [hist8, hist_element8'];  
      end
      hist8 = hist8';     clear hist_element8;
      index_KD(1, 8) = meig; 
   end
      
nummax = 0;
for i = 1: nattr
    if n_histcount(1, i) > nummax
        nummax = n_histcount(1, i);
    end
end
disp('max is : ');
fprintf('%d\n', nummax);
max_histcount = nummax;    index_maxhistcount = find(n_histcount(1, :) == max_histcount);     % get max noisy count and its location
hist = zeros(max_histcount, nattr);
hist(1:(n_histcount(1, 1)), 1) = hist1;    hist(1:(n_histcount(1, 2)), 2) = hist2; 
if nattr >= 3
    hist(1:(n_histcount(1, 3)), 3) = hist3;
end
if nattr >= 4
    hist(1:(n_histcount(1, 4)), 4) = hist4;
end
if nattr >= 5
    hist(1:(n_histcount(1, 5)), 5) = hist5;
end
if nattr >= 6
    hist(1:(n_histcount(1, 6)), 6) = hist6;
end
if nattr >= 7
    hist(1:(n_histcount(1, 7)), 7) = hist7;
end
if nattr >= 8
    hist(1:(n_histcount(1, 8)), 8) = hist8;
end
for i = 1:nattr
     filepath = [dir, num2str(epsilon), '\', num2str(t), '\e_marginal', num2str(i), '.txt']; 
     fid = fopen(filepath,'w');   
     fprintf(fid,'%d\r\n',hist(1:n_histcount(1,i), i));     % write noisy marginal distribution to a file FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
    % size(hist(i, 1:round(n_histcount(1,i)), 1)')
     if  i ~= index_maxhistcount
         num11 = 0; nummax = max_histcount; m1 = n_histcount(1, i);  j = 0;
         if i == 1             
             for  index_A = 1: index_KD(1, i)
               if floor((A(index_A, 4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((A( index_A, 4)/m1)*(nummax-m1));
                   min = A( index_A, 1);   max = A( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((A( index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j == 0
                   j = index_KD(1, i);
               end
               min = A(j,1);    max = A(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
         end % if i == 1
         if i == 2
             for  index_A = 1: index_KD(1, i)
               if floor((H(index_A, 4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((H(index_A, 4)/m1)*(nummax-m1));
                   min = H(index_A, 1);   max = H(index_A, 2);
                   hist_element = min + (max-min)*rand(floor((H(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = H(j,1);    max = H(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
         end % if i == 2
         if i == 3 
             for  index_A = 1: index_KD(1, i)
               if floor((INC(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((INC(index_A,4)/m1)*(nummax-m1));
                   min = INC( index_A, 1);   max = INC( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((INC(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = INC(j,1);    max = INC(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 
        if i == 4 
             for  index_A = 1: index_KD(1, i)
               if floor((OC(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((OC(index_A,4)/m1)*(nummax-m1));
                   min = OC( index_A, 1);   max = OC( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((OC(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = OC(j,1);    max = OC(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 4
        if i == 5 
             for  index_A = 1: index_KD(1, i)
               if floor((WC(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((WC(index_A,4)/m1)*(nummax-m1));
                   min = WC( index_A, 1);   max = WC( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((WC(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = WC(j,1);    max = WC(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 5
        if i == 6
             for  index_A = 1: index_KD(1, i)
               if floor((SIX(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((SIX(index_A,4)/m1)*(nummax-m1));
                   min = SIX( index_A, 1);   max = SIX( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((SIX(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = SIX(j,1);    max = SIX(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 5
        if i == 7 
             for  index_A = 1: index_KD(1, i)
               if floor((SEV(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((SEV(index_A,4)/m1)*(nummax-m1));
                   min = SEV( index_A, 1);   max = SEV( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((SEV(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                   j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = SEV(j,1);    max = SEV(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 5
        if i == 8 
             for  index_A = 1: index_KD(1, i)
               if floor((EIG(index_A,4)/m1)*(nummax-m1)) > 0
                   num11 = num11 + floor((EIG(index_A,4)/m1)*(nummax-m1));
                   min = EIG( index_A, 1);   max = EIG( index_A, 2);
                   hist_element = min + (max-min)*rand(floor((EIG(index_A, 4)/m1)*(nummax-m1)),1);          
                   fprintf(fid,'%d\r\n',round(hist_element));
                    j = index_A;
               end
             end
             if  num11<(nummax-m1)
               if   j ==0
                   j = index_KD(1, i);
               end
               min = EIG(j,1);    max = EIG(j,2);
               hist_element = min + (max-min)*rand((nummax-m1)-num11,1);
               fprintf(fid,'%d\r\n',round(hist_element));
             end
        end % if i == 5
     end
     fclose(fid);     % clear extra_hist;
end

